package t_final;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class servidor {

	public static void main(String[] args) {

		ServerSocket servidor= null;
		Socket s= null;
		DataInputStream in;
		DataOutputStream out;
		
		final int Puerto = 64000;
		try {
			servidor = new ServerSocket(Puerto);
			
			System.out.println("El servidor a iniciado: ");
			
			while(true) {
				s=servidor.accept();
				//espera una instruccion
				System.out.println("Cliente conectado");
				in= new DataInputStream(s.getInputStream());
				out= new DataOutputStream(s.getOutputStream());
				
				String mensaje = in.readUTF();
				System.out.println(mensaje);
				
				out.writeUTF("Conexion desde el servidor: ");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
