package t_final;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Random;

public class Lista {

	public static void main(String[] args) {
		final int Puerto= 64000;
		
				Lista a= new Lista();
				System.out.println("Registremos los numeros: ");
				a.getStreamOfRandomInts(99);
			
		}
			public static void getStreamOfRandomInts(int num) {
				Random random = new Random();
				random.ints(num).sorted().forEach(System.out::println);				
			}
	}


